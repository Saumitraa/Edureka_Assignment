package com.tcs;

import java.util.Optional;

import com.tcs.model.Employee;
import com.tcs.service.EmployeeService;
import com.tcs.service.EmployeeServiceImpl;

public class Main {
	 public static void main(String[] args) {
		 
		 	Employee employee = null;
		 	employee = new Employee(100L, 25L, 1L, "Saumitra", 25, "Engineer");
			
			EmployeeService empService =  EmployeeServiceImpl.getInstance();
			
			String result = empService.addEmployee(employee);
			
			
			if("success".equals(result)) {
				System.out.println("Success");
			}
			else {
				System.out.println("Problem");
			}
			
			Optional<Employee> optional= empService.findById(1);
			
			if(optional.isPresent()) {
				Employee emp2 = optional.get();
				System.out.println(emp2);
			}
			else {
				System.out.println("product is not available");
			}
		 
	}
}

//Did not understand as to where the menu driven should ! should there be a choice to choose from employee/department/organization 
// OR
// A menu for adding,updating deleting etc. 