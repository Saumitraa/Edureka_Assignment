package com.tcs.service;

import java.util.List;
import java.util.Optional;

import com.tcs.dao.EmployeeDAO;
import com.tcs.dao.EmployeeRepository;
import com.tcs.model.Employee;

public class EmployeeServiceImpl implements EmployeeService {
	
	EmployeeDAO employeeDao = EmployeeRepository.getInstance();
		
		private static EmployeeService dao;
		public static EmployeeService getInstance(){
			if(dao==null) {
				dao = new EmployeeServiceImpl();
				return dao;
			}
			return dao;
		}
		
	@Override
	public String addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return employeeDao.addEmployee(employee);
	}
	@Override
	public String updateEmployee(long id) {
		// TODO Auto-generated method stub
		return employeeDao.updateEmployee(id);
	}
	@Override
	public String deleteEmployee(long id) {
		// TODO Auto-generated method stub
		return employeeDao.deleteEmployee(id);
	}
	@Override
	public Optional<Employee> findById(long id) {
		// TODO Auto-generated method stub
		return employeeDao.findById(id);
	}
	@Override
	public Optional<List<Employee>> getEmployees() {
		// TODO Auto-generated method stub
		return employeeDao.getEmployees();
	}
	@Override
	public Optional<List<Employee>> findByOrganizationId(long id) {
		// TODO Auto-generated method stub
		return employeeDao.findByOrganizationId(id);
	}

}
