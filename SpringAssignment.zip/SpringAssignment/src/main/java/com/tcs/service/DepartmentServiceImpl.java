package com.tcs.service;

import java.util.List;
import java.util.Optional;

import com.tcs.dao.DepartmentDAO;
import com.tcs.dao.DepartmentRepository;
import com.tcs.model.Department;

public class DepartmentServiceImpl implements DepartmentService {
	
	DepartmentDAO departmentDao = DepartmentRepository.getInstance();
	
	private static DepartmentService dao;
	public static DepartmentService getInstance(){
		if(dao==null) {
			dao = new DepartmentServiceImpl();
			return dao;
		}
		return dao;
	}
	
	@Override
	public String addDepartment(Department department) {
		// TODO Auto-generated method stub
		return departmentDao.addDepartment(department);
	}

	@Override
	public String updateDepartment(long id) {
		// TODO Auto-generated method stub
		return departmentDao.updateDepartment(id);
	}

	@Override
	public String deleteDepartment(long id) {
		// TODO Auto-generated method stub
		return departmentDao.deleteDepartment(id);
	}

	@Override
	public Optional<Department> findById(long id) {
		// TODO Auto-generated method stub
		return departmentDao.findById(id);
	}

	@Override
	public Optional<List<Department>> getDepartments() {
		// TODO Auto-generated method stub
		return departmentDao.getDepartments();
	}

	@Override
	public Optional<List<Department>> findByOrganizationId(long id) {
		// TODO Auto-generated method stub
		return departmentDao.findByOrganizationId(id);
	}

}
