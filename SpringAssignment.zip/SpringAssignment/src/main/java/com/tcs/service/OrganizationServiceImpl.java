package com.tcs.service;

import java.util.List;
import java.util.Optional;

import com.tcs.dao.OrganizationDAO;
import com.tcs.dao.OrganizationRepository;
import com.tcs.model.Organization;

public class OrganizationServiceImpl implements OrganizationService {
	
	OrganizationDAO organizationDao = OrganizationRepository.getInstance();
	
	private static OrganizationService dao;
	public static OrganizationService getInstance(){
		if(dao==null) {
			dao = new OrganizationServiceImpl();
			return dao;
		}
		return dao;
	}
	@Override
	public String addOrganization(Organization organization) {
		// TODO Auto-generated method stub
		return organizationDao.addOrganization(organization);
	}

	@Override
	public String updateOrganization(long id) {
		// TODO Auto-generated method stub
		return organizationDao.updateOrganization(id);
	}

	@Override
	public String deleteOrganization(long id) {
		// TODO Auto-generated method stub
		return organizationDao.deleteOrganization(id);
	}

	@Override
	public Optional<Organization> findById(long id) {
		// TODO Auto-generated method stub
		return organizationDao.findById(id);
	}

	@Override
	public Optional<List<Organization>> getOrganizations() {
		// TODO Auto-generated method stub
		return organizationDao.getOrganizations();
	}

	@Override
	public Optional<List<Organization>> findByOrganizationId(long id) {
		// TODO Auto-generated method stub
		return organizationDao.findByOrganizationId(id);
	}

}
