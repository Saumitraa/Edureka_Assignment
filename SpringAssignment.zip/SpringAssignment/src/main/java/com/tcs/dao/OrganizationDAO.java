package com.tcs.dao;

import java.util.List;
import java.util.Optional;

import com.tcs.model.Organization;

public interface OrganizationDAO {
	public String addOrganization(Organization organization);
	public String updateOrganization(long id);
	public String deleteOrganization(long id);
	public Optional<Organization> findById(long id);
	public Optional<List<Organization>> getOrganizations();
	public Optional<List<Organization>> findByOrganizationId(long id);
}
