package com.tcs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


import com.tcs.model.Organization;
import com.tcs.utils.DBUtils;

public class OrganizationRepository implements OrganizationDAO {
	
	private static OrganizationDAO dao;
	
	public static OrganizationDAO getInstance() {	
		if(dao==null) {
			dao = new OrganizationRepository();
			return dao;
		}
		return dao;
	}

	@Override
	public String addOrganization(Organization organization) {
		// TODO Auto-generated method stub
		Connection connection = DBUtils.getConnection();
		PreparedStatement preparedStatement = null;
		int result = 0;
		String insertProduct = "insert into Organization (id,organizationId,name) values(?,?,?)";
		try {
			 preparedStatement = connection.prepareStatement(insertProduct);
			 preparedStatement.setLong(1, organization.getId());
			 preparedStatement.setString(2, organization.getName());
			 preparedStatement.setString(3, organization.getAddress());
			 
			 result = preparedStatement.executeUpdate();
			 
			 if(result>0)
			 {
				 connection.commit();
				 return "success";
				 
			 }
			 else {
				 return "fail";
			 }
		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "fail";
		}
		finally {
			DBUtils.closeConnection(connection);
		}
	}

	@Override
	public String updateOrganization(long id) {
		// TODO Auto-generated method stub
		Connection connection = DBUtils.getConnection();
		PreparedStatement preparedStatement = null;
		int result = 0;
		Organization organization = null;
		String insertProduct = "update Department SET name = ?, address = ?,  where id = ?";
		try {
			organization = new Organization();
			preparedStatement = connection.prepareStatement(insertProduct);
			preparedStatement.setLong(3, id);
			preparedStatement.setString(1, organization.getName());
			preparedStatement.setString(2, organization.getAddress());
			
			result = preparedStatement.executeUpdate();
			
			if(result>0) {
				connection.commit();
				return "success";
			}
			else {
				return "problem";
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			try {
				connection.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "fail";
		}
		finally {
			DBUtils.closeConnection(connection);
		}
	}

	@Override
	public String deleteOrganization(long id) {
		// TODO Auto-generated method stub
		Connection connection = DBUtils.getConnection();
		PreparedStatement preparedStatement = null;
		int result = 0;
		String insertProduct = "Delete From Organization where id = ?";
		try {
			preparedStatement = connection.prepareStatement(insertProduct);
			preparedStatement.setLong(1, id);
			
			result = preparedStatement.executeUpdate();
			
			if(result>0) {
				connection.commit();
				return "success";
			}
			else {
				return "problem";
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			try {
				connection.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "fail";
		}
		finally {
			DBUtils.closeConnection(connection);
		}
	}

	@Override
	public Optional<Organization> findById(long id) {
		// TODO Auto-generated method stub
		Connection connection = DBUtils.getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		Organization organization = null;
		String query = "SELECT * FROM Organization WHERE id = ?";
		
		try {
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setLong(1, id);
			
			resultSet = preparedStatement.executeQuery();
			
			if(resultSet.next()) {
				organization = new Organization();
				organization.setId(resultSet.getLong("id"));
				organization.setName(resultSet.getString("name"));
				organization.setAddress(resultSet.getString("address"));
			}
			
		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			// TODO Auto-generated catch block
			e.printStackTrace();
			return Optional.empty();
		}
		finally {
			DBUtils.closeConnection(connection);
		}
		
		return Optional.of(organization);
	}

	@Override
	public Optional<List<Organization>> getOrganizations() {
		// TODO Auto-generated method stub
		Connection connection = DBUtils.getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		Organization organization = null;
		List<Organization> list = new ArrayList<>();
		
		String query = "SELECT * FROM Organization";
		
		try {
			preparedStatement = connection.prepareStatement(query);
			
			resultSet = preparedStatement.executeQuery();
			
			if(resultSet.next()) {
				organization = new Organization();
				organization.setId(resultSet.getLong("id"));
				organization.setName(resultSet.getString("name"));
				organization.setAddress(resultSet.getString("address"));
				
				list.add(organization);
			}
			
		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			// TODO Auto-generated catch block
			e.printStackTrace();
			return Optional.empty();
		}
		finally {
			DBUtils.closeConnection(connection);
		}
		
		return Optional.of(list);
	}

	@Override
	public Optional<List<Organization>> findByOrganizationId(long id) {
		// TODO Auto-generated method stub
		Connection connection = DBUtils.getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		Organization organization = null;
		List<Organization> list = new ArrayList<>();
		String query = "SELECT * FROM Organization WHERE organizationId = ?";
		
		try {
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setLong(1, id);
			
			resultSet = preparedStatement.executeQuery();
			
			if(resultSet.next()) {
				organization = new Organization();
				organization.setId(resultSet.getLong("id"));
				organization.setName(resultSet.getString("name"));
				organization.setAddress(resultSet.getString("address"));
				
				list.add(organization);
			}
			
		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			// TODO Auto-generated catch block
			e.printStackTrace();
			return Optional.empty();
		}
		finally {
			DBUtils.closeConnection(connection);
		}
		
		return Optional.of(list);
	}

}
